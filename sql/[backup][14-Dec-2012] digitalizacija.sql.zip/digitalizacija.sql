-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: 50.63.244.137
-- Generation Time: Dec 17, 2012 at 01:12 PM
-- Server version: 5.0.92
-- PHP Version: 5.1.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `digitalizacija`
--

-- --------------------------------------------------------

--
-- Table structure for table `baza`
--

CREATE TABLE `baza` (
  `id` int(255) NOT NULL auto_increment,
  `inv` varchar(255) character set utf8 collate utf8_unicode_ci default NULL,
  `autor` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT 'Ime autora',
  `naziv` varchar(512) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT 'Naziv dela',
  `godina` int(5) default NULL COMMENT 'Godina nastanka',
  `dim` varchar(20) default NULL COMMENT 'Dimenzije',
  `graf_dim_l` varchar(20) character set utf8 collate utf8_unicode_ci default NULL COMMENT 'Dimenzije lista (grafika)',
  `graf_dim_o` varchar(20) character set utf8 collate utf8_unicode_ci default NULL COMMENT 'Dimenzije otiska (grafika)',
  `duzina` varchar(255) character set utf8 collate utf8_unicode_ci default NULL COMMENT 'Dužina trajanja (video)',
  `zbirka` varchar(512) character set utf8 collate utf8_unicode_ci default NULL COMMENT 'Naziv zbirke',
  `tehnika` varchar(512) character set utf8 collate utf8_unicode_ci default NULL COMMENT 'Tehnika (za sada VARCHAR)',
  `medij` int(11) NOT NULL COMMENT 'Vrsta medija',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `baza`
--

INSERT INTO `baza` VALUES(1, '476', 'Viktor Vazareli', 'Grafika', 1971, NULL, '67,6 x 67,4', '59,8 x 60,1', NULL, '1', '12', 1);
INSERT INTO `baza` VALUES(2, '473', 'Hundertwasser Friedensreich', 'Exodus into space', 1971, NULL, '49,3 x 66,8', '41,5 x 59,0', NULL, '1', '10', 1);
INSERT INTO `baza` VALUES(3, '477', 'Marko Spalatin', 'Cube exit', 1971, NULL, '77,5 x 64,6', '59,5 x 50,1', NULL, '1', '15', 1);
INSERT INTO `baza` VALUES(4, '1320', 'Branko Andrić', 'Situation XIII', 1974, NULL, '49,8 x 62,6', '44,3 x 58,0', NULL, '1', '13', 1);
INSERT INTO `baza` VALUES(5, NULL, 'Bojan Bem', 'Konkviskador', 1968, '49,9 x 62,3', NULL, NULL, NULL, '1', '16', 4);
INSERT INTO `baza` VALUES(6, '1323', 'Kristinel Bečejski Mihaela', 'Pokret I', 1985, NULL, '49,8 x 70,3', '40,5 x 46,0', NULL, '1', '5', 1);
INSERT INTO `baza` VALUES(7, '1022', 'Lamut Sonja', 'Deposition', 1977, NULL, '65,5 x 50,2', '48,4 x 37,0', NULL, '1', '9', 1);
INSERT INTO `baza` VALUES(8, '421', 'Ferenc Mauric', 'Strelište 1', 1971, '98,7 x 99,8', NULL, NULL, NULL, '2', '17', 2);
INSERT INTO `baza` VALUES(9, '781', 'Blanuša Milan', 'Grupa XII', 1976, '80,3 x 80,9', NULL, NULL, NULL, '2', '17', 2);
INSERT INTO `baza` VALUES(10, '910', 'Vladimir Jovanović', 'Portret umetnika sa idolom', 1976, '109,9 x 89,0', NULL, NULL, NULL, '2', '17', 2);
INSERT INTO `baza` VALUES(11, '1324', 'Ljubiša Bogosavljević i Miodrag Miljković', 'Mija-Ljubiša', 1984, '149,8 x 110,0', NULL, NULL, NULL, '2', '17', 2);
INSERT INTO `baza` VALUES(12, '1954', 'Petrik Pal', 'Zimska tragedija', NULL, '69,8 x 99,9', NULL, NULL, NULL, '2', '8', 2);
INSERT INTO `baza` VALUES(13, '2011', 'Mira Brtka', 'Costruzione V', 1965, '130,0 x 96,9', NULL, NULL, NULL, '2', '17', 2);
INSERT INTO `baza` VALUES(14, NULL, 'Ištvan Sajko', 'Mlada', 1969, '90,0 x 140,5', NULL, NULL, NULL, '2', '17', 2);
INSERT INTO `baza` VALUES(15, '1351', 'Oto Logo', 'Katedrala V', 1984, '49,0 x 41,0 x 19,0', NULL, NULL, NULL, '3', '1', 3);
INSERT INTO `baza` VALUES(16, '478', 'Josip Diminić', 'Osjet ljubavi', 1972, '56,0 x 47,0 x 17,0', NULL, NULL, NULL, '3', '11', 3);
INSERT INTO `baza` VALUES(17, '1244', 'Borislav Šuput', 'Pisaća mašina', 1979, '59,0 x 77,0 x 55,0', NULL, NULL, NULL, '3', '3', 3);
INSERT INTO `baza` VALUES(18, NULL, 'Rastislav Škulec', 'AK-991', 1991, '100,0 x 40,0 x 100,0', NULL, NULL, NULL, '3', '2', 3);
INSERT INTO `baza` VALUES(19, '1301', 'Slobodan Bodulić', 'Struktura', 1980, '77,0 x 65,0 x 45,0', NULL, NULL, NULL, '3', '4', 3);
INSERT INTO `baza` VALUES(20, NULL, 'Slobodan Vilček', 'U snu val', 2000, '73,0 x 72,0 x 19,0', NULL, NULL, NULL, '3', '8', 8);
INSERT INTO `baza` VALUES(21, NULL, 'Laslo Kerekeš', '20 godina grupe BOSCH+BOSCH', 1989, '27,0 x 23,3 x 7,0', NULL, NULL, NULL, '4', '8', 8);
INSERT INTO `baza` VALUES(22, '438-1', 'Slavko Matković', 'U slavu grupe OHO', 1977, '29,1 x 20,8', NULL, NULL, NULL, '4', '7', 4);
INSERT INTO `baza` VALUES(23, '438-2', 'Slavko Matković', 'Esej o grupi BOSCH+BOSCH', 1975, '29,7 x 21,1', NULL, NULL, NULL, '4', '7', 4);
INSERT INTO `baza` VALUES(24, '2176-1', 'Atila Černik', 'Telopis', 1975, '52,3 x 35,1', NULL, NULL, NULL, '4', '6', 5);
INSERT INTO `baza` VALUES(25, '2176-2', 'Atila Černik', 'Telopis', 1975, '50,4 x 34,6', NULL, NULL, NULL, '4', '6', 5);
INSERT INTO `baza` VALUES(26, '2176-3', 'Atila Černik', 'Telopis', 1975, '51,9 x 34,4', NULL, NULL, NULL, '4', '6', 5);
INSERT INTO `baza` VALUES(27, '454-1', 'Slavko Matković', 'Film o grupi BOSCH+BOSCH', 1972, NULL, NULL, NULL, '00:03:02', '4', '14', 6);
INSERT INTO `baza` VALUES(28, NULL, 'Božidar Mandić, Porodica bistrih potoka', 'Manijak 7001', 1974, NULL, NULL, NULL, '00:07:25', '4', '14', 6);

-- --------------------------------------------------------

--
-- Table structure for table `mediji`
--

CREATE TABLE `mediji` (
  `med_id` int(255) NOT NULL auto_increment COMMENT 'id',
  `med_naziv_sr` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT 'Naziv tehnike',
  `med_naziv_en` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL COMMENT 'Naziv (engleski)',
  `med_naziv_de` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`med_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `mediji`
--

INSERT INTO `mediji` VALUES(1, 'grafika', 'graphics', '');
INSERT INTO `mediji` VALUES(2, 'slika', 'painting', '');
INSERT INTO `mediji` VALUES(3, 'skulptura', 'sculpture', '');
INSERT INTO `mediji` VALUES(4, 'crtež', 'drawing', '');
INSERT INTO `mediji` VALUES(5, 'fotografija', 'photography', '');
INSERT INTO `mediji` VALUES(6, 'video', 'video', '');
INSERT INTO `mediji` VALUES(7, 'instalacija', 'installation', '');
INSERT INTO `mediji` VALUES(8, 'objekat', 'object', '');

-- --------------------------------------------------------

--
-- Table structure for table `tehnike`
--

CREATE TABLE `tehnike` (
  `teh_id` int(255) NOT NULL auto_increment,
  `teh_naziv_sr` varchar(100) NOT NULL COMMENT 'Naziv tehnike na srpskom',
  `teh_naziv_en` varchar(100) NOT NULL COMMENT 'Naziv tehnike na engleskom',
  `teh_naziv_de` varchar(100) NOT NULL COMMENT 'Naziv tehnike na nemačkom',
  PRIMARY KEY  (`teh_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tehnike`
--

INSERT INTO `tehnike` VALUES(1, 'Bronza', 'Bronze', '');
INSERT INTO `tehnike` VALUES(2, 'Čelik', 'Steel', '');
INSERT INTO `tehnike` VALUES(3, 'Drvo', 'Wood', '');
INSERT INTO `tehnike` VALUES(4, 'Drvo/metal', 'Wood/Steel', '');
INSERT INTO `tehnike` VALUES(5, 'Drvorez', 'Wood carving', '');
INSERT INTO `tehnike` VALUES(6, 'Fotografija', 'Photography', '');
INSERT INTO `tehnike` VALUES(7, 'Kolaž/Crtež', 'Collage/Drawing', '');
INSERT INTO `tehnike` VALUES(8, 'Kombinovana tehnika', 'Combined technique', '');
INSERT INTO `tehnike` VALUES(9, 'Mecotinta', 'Mezzotint', '');
INSERT INTO `tehnike` VALUES(10, 'Ofsetna štampa', 'Offset print', '');
INSERT INTO `tehnike` VALUES(11, 'Poliester', 'Polyester', '');
INSERT INTO `tehnike` VALUES(12, 'Serigrafija', 'Serigraphy', '');
INSERT INTO `tehnike` VALUES(13, 'Sito štampa', 'Screen print', '');
INSERT INTO `tehnike` VALUES(14, 'Super 8 film', 'Super 8 film', '');
INSERT INTO `tehnike` VALUES(15, 'Svilotisak', 'Silkscreen print', '');
INSERT INTO `tehnike` VALUES(16, 'Tuš i flomaster', 'Ink and Marker pen', '');
INSERT INTO `tehnike` VALUES(17, 'Ulje na platnu', 'Oil on canvas', '');

-- --------------------------------------------------------

--
-- Table structure for table `zbirke`
--

CREATE TABLE `zbirke` (
  `zbr_id` int(255) NOT NULL auto_increment,
  `zbr_naziv_sr` varchar(100) NOT NULL COMMENT 'Naziv zbirke na srpskom',
  `zbr_naziv_en` varchar(100) NOT NULL COMMENT 'Naziv zbirke na engleskom',
  `zbr_naziv_de` varchar(100) NOT NULL COMMENT 'Naziv zbirke na nemačkom',
  PRIMARY KEY  (`zbr_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `zbirke`
--

INSERT INTO `zbirke` VALUES(1, 'Zbirka crteža, grafika i radova na papiru', 'Collection of Drawings, Printworks and works on paper', '');
INSERT INTO `zbirke` VALUES(2, 'Zbirka slikarstva', 'Collection of Paintings', '');
INSERT INTO `zbirke` VALUES(3, 'Zbirka skulptura, objekata i instalacija', 'Collection of Sculptures, Objects and Instalations', '');
INSERT INTO `zbirke` VALUES(4, 'Zbirka konceptualne umetnosti i novih medija', 'Collection of Conceptual art', '');
